#ifndef _key_
#define _key_
#include "stm32f10x.h"
#define GPIO_KEY GPIOC
#define RCC_GPIO_KEY RCC_APB2Periph_GPIOC
void KeyGPIO_Init(void); 

u8 Read_KeyValue(void); 

#endif

