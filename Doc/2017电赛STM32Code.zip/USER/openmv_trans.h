#ifndef _OPENMV_TRANS_H_
#define _OPENMV_TRANS_H_
#include "stm32f10x.h"
#define CAMERA_FRANEHEAD    '$'
#define CAMERA_FRAMEDIV     ','
#define CAMERA_FRAMETAIL    '#'
#define CAMERA_FRAMELEN     3

typedef struct
{
  unsigned short ucPosX;
  unsigned short ucPosY;
}Camera_DataTypeDef;

void Camera_ReceiveData(unsigned char ucData);
void Camera_TranslateData(Camera_DataTypeDef* data);
void Camera_ResetFlag(void);
FlagStatus Camera_GetFalg(void);
#endif
