/**
  ******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "delay.h"
#include "sys.h"

extern uint16_t table[8];
extern int8_t tt,a;
extern u8 Read_KeyValue(void);
extern u8 flag;
extern u8 mode;

unsigned char Re_buf[11],temp_buf[11],counter=0;
unsigned char sign,t,he;
//static unsigned char Temp[11];
void NMI_Handler(void)
{
}
 
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
 
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

 
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}
 
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}
 
void SVC_Handler(void)
{
}
 
void DebugMon_Handler(void)
{
}
 
void PendSV_Handler(void)
{
}
 
void SysTick_Handler(void)
{
}
#include "openmv_trans.h"

void USART2_IRQHandler(void)
{	
// if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  //�����ж���Ч,���������ݼĴ�����
//     {
//      Camera_ReceiveData(USART_ReceiveData(USART2));  //��������
      //�������ĳ���
      //if(counter == 0 && Re_buf[0] != 0x55) return;      //�� 0 �����ݲ���֡ͷ������
//	  if(counter == 0 && Temp[0] != 0x55) return;      //�� 0 �����ݲ���֡ͷ������
//      counter++; 
//      if(counter==11) //���յ� 11 ������
//      { 
//         memcpy(Re_buf,Temp,11);
//         counter=0; //���¸�ֵ��׼����һ֡���ݵĽ���
//         sign=1;
//			}
  if(USART_GetITStatus(USART2, USART_IT_RXNE))
  {
    Camera_ReceiveData(USART_ReceiveData(USART2));
   //USART_ClearITPendingBit(USART2, USART_IT_RXNE);
  }
//}
}

//void USART3_IRQHandler(void)
//	{


//  if(USART_GetITStatus(USART3, USART_IT_RXNE))
//  {
//    Camera_ReceiveData(USART_ReceiveData(USART3));
//    USART_ClearITPendingBit(USART3, USART_IT_RXNE);
//  }



//}
//	
//	
	

void EXTI0_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line0) != RESET) //ȷ���Ƿ������EXTI Line�ж�
  {
		delay_ms(200);
		mode++;
		if(mode==10)
		{
			mode=0;
		}
		//OLED_ShowNum(30,4,32,3,16);
	  // LED1 ȡ��		
	//	GPIO_WriteBit(GPIOC, GPIO_Pin_3, 
		       //      (BitAction)((1-GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_3))));
    EXTI_ClearITPendingBit(EXTI_Line0);     //����жϱ�־λ
  }  
}
	
	void EXTI4_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line4) != RESET) //ȷ���Ƿ������EXTI Line�ж�
	{
		OLED_ShowNum(30,4,10,3,16);
		// LED1 ȡ��		
		GPIO_WriteBit(GPIOC, GPIO_Pin_3, 
			(BitAction)((1-GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_3))));
		EXTI_ClearITPendingBit(EXTI_Line5);     //����жϱ�־λ
	}  
}

	
//void TIM3_IRQHandler(void)
//{
//	if ( TIM_GetITStatus(TIM3 , TIM_IT_Update) != RESET ) 
//	{	
//		TIM_ClearITPendingBit(TIM3, TIM_FLAG_Update);    
//   	tt=Read_KeyValue();
//		if(tt!=20)
//		{
//		 	a=tt;
//			if(a==14)
//			{
//				flag=0;
//				a=20;
//			}
//			
//   	}
//	}		 	
//}
/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/
