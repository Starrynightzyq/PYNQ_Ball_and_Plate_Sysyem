#include "openmv_trans.h"
#include <stdlib.h>

volatile static FlagStatus Camera_PosFlag=RESET;
static char Camera_DataBuffer[2][CAMERA_FRAMELEN+2];
static uint8_t Camera_DataCounter=0;
static uint8_t Camera_RowCounter=0;

void Camera_ReceiveData(uint8_t ucData)
{
  Camera_DataBuffer[Camera_RowCounter][Camera_DataCounter] = ucData;
  
	// 	printf( "%d",ucData);
  if((!Camera_DataCounter) && (!Camera_RowCounter) && (CAMERA_FRANEHEAD != ucData))
    return;
  if(CAMERA_FRAMEDIV == ucData)
  {
    Camera_RowCounter++;
    Camera_DataCounter = 0;
    return;
  }
  Camera_DataCounter++;
  if(CAMERA_FRAMETAIL == ucData)
  {
    Camera_RowCounter = 0;
    Camera_DataCounter = 0;
    Camera_PosFlag = SET;
  }
}

void Camera_TranslateData(Camera_DataTypeDef* data)
{
  if(CAMERA_FRANEHEAD == Camera_DataBuffer[0][0])
  {
    data->ucPosX = atoi(&(Camera_DataBuffer[0][1]));
    data->ucPosY = atoi(&(Camera_DataBuffer[1][0]));
  }
}

void Camera_ResetFlag(void)
{
  Camera_PosFlag=RESET;
}

FlagStatus Camera_GetFalg(void)
{
  return Camera_PosFlag;
}

