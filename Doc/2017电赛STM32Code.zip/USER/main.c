#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"
#include "string.h"
#include "ov7670.h"
#include "tpad.h"
#include "timer.h"
#include "exti.h"
#include "usmart.h"
#include  "pwm.h"
#include  "math.h"
#include   "oled.h"

#include "openmv_trans.h"

/************************************************
 ALIENTEKս��STM32������ʵ��35
 ����ͷOV7670 ʵ��
 ����֧�֣�www.openedv.com
 �Ա����̣�http://eboard.taobao.com
 ��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡSTM32���ϡ�
 �������������ӿƼ����޹�˾
 ���ߣ�����ԭ�� @ALIENTEK
************************************************/



extern u8 ov_sta;	//��exit.c�� �涨��
extern u8 ov_frame;	//��timer.c���涨��

u8 X, Y = 0;   //С���������Ϣ



int PWM_X, PWM_Y = 0;       //pid������ʼ��
float Err_X, Err_Y = 0;
float Err_X_LAST, Err_Y_LAST, SumError_X, SumError_Y = 0;
float Aim_X, Aim_Y = 0;
float Kp_x, Ki_x, Kd_x = 0;
float Kp_y, Ki_y, Kd_y = 0;
u16 k;
u16 d;

u16  m;
u8 flag6_2s;

u8 flag_2s;
u8 flag_1s;

u16 table_x[] = {80, 78, 82, 163, 169, 170, 235, 246, 247}, table_y[] = {210, 131, 35, 211, 134, 44, 204, 132, 52}, table_setx[4], table_sety[4];

u32  ttt;
u8 asd = 0;
u8 dsa = 0;
u8 CurMode = 1;
uint16_t table[8];
int8_t tt = 0, abc = 20;
u8 flag = 0;
u8 key_question = 15;
u8 key = 20;
u8 mode = 0;


u8  flag_t0;
u8  flag_t1;
u8  flag_t2;
u8  flag_t3;


u8  R = 80;

//	void Mode_6(void)
//{
//   	u8 num=20,i;
//  u16  juedui_x;
//	u16  juedui_y;
//	static  u8 key_flag=1;
//
//	if ( key_flag  )
//	{
//		OLED_Clear();
//		OLED_ShowChar(8,0,'A');
//		OLED_ShowChar(8,2,'B');
//		OLED_ShowChar(8,4,'C');
//		OLED_ShowChar(8,6,'D');
//	for(i=0;i<4;i++)
//	{
//		while(num==20)
//		{
//			num=Read_KeyValue();
//		}
//		OLED_ShowNum(56,i*2,num,1,16);
//		table_setx[i]=table_x[num-1];table_sety[i]=table_y[num-1];num=20;
//
//	}
//	key_flag=0;OLED_Clear();
//}

//
//		TIM_Cmd(TIM5, ENABLE);
//	if (flag_2s==1  )
//	{
//		flag_2s=0;
//		asd++;
//		if (asd>20)
//   {
//
//	 TIM_Cmd(TIM5, DISABLE);
//   TIM5->CNT=0;
//	 }
//	}
//
//
//
//	if (flag_t0!=1){
//
//	  if (X-table_setx[0]>0)
//		{
//		juedui_x=X-table_setx[0];
//		}
//		else
//		{
//			juedui_x=table_setx[0]-X;
//		}
//		if (Y-table_sety[0]>0)
//		{
//		juedui_y=Y-table_sety[0];
//		}
//		else
//		{
//			juedui_y=table_setx[0]-Y;
//		}
//		if ((juedui_x<85)||(juedui_y<85))
//		{
//		  if (((juedui_x<10)&&(juedui_y>120))||((juedui_y<10)&&(juedui_x>120)))
//			{
//           Aim_X=X+30;
//				if ((Aim_X<90)||(Aim_X>250))
//         {Aim_X=X-30;}
//
//				  Aim_Y=Y+30;
//				if ((Aim_Y<90)||(Aim_Y>250))
//         {Aim_Y=Y-30;}
//
//				}
//
//		   else
//			 {
//	       	Aim_X=table_setx[0];
//	       	Aim_Y=table_sety[0];
//			 }
//
//
//
//		}
//	  else
//		{
//		      Aim_X=X+30;
//				if ((Aim_X<90)||(Aim_X>250))
//         {Aim_X=X-30;}
//
//
//				  Aim_Y=Y+100;
//				if ((Aim_Y<90)||(Aim_Y>250))
//         {Aim_Y=Y-100;}
//

//		}
//
//	  flag_t0=1;
//		TIM_Cmd(TIM6, ENABLE);
//
//	}
//
//	if(flag6_2s==1)
//	{
//	 TIM_Cmd(TIM6, DISABLE);
//   TIM6->CNT=0;
//
//
//		Aim_X=table_setx[0];
//		Aim_Y=table_sety[0];
//
//	}
//

//	if (asd>0)
//	{
//		Aim_X=table_setx[1];
//		Aim_Y=table_sety[1];
//		}
//	if(asd>1)
//	{
//		Aim_X=table_setx[2];
//		Aim_Y=table_sety[2];
//	}
//	if(asd>2)
//	{
//		Aim_X=table_setx[3];
//		Aim_Y=table_sety[3];
//	}
//
//	  Kp_x=-2;//-      -2
//	  Ki_x=-0.01;
//		Kd_x=-16;  //2.7
//
//	  Kp_y=2;  //+
//	  Ki_y=0.01;
//		Kd_y=16;//+
//

//
//		Err_X=X-Aim_X;
//		Err_Y=Y-Aim_Y;
//
//		SumError_X+=Err_X;
//		SumError_Y+=Err_Y;
//
//
//		if(SumError_X >1000.0)					//�����޷�
//		SumError_X = 1000.0;
//	  else if(SumError_X < -1000.0)
//    SumError_X = -1000.0;
//
//		if(SumError_Y > 1000.0)					//�����޷�
//		SumError_Y = 1000.0;
//	  else if(SumError_Y < -1000.0)
//    SumError_Y = -1000.0;
//	//printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);
//
//		PWM_X=750+(Err_X*Kp_x+SumError_X*Ki_x +(Err_X-Err_X_LAST)*Kd_x);
//		PWM_Y=680+(Err_Y*Kp_y+SumError_Y*Ki_y +(Err_Y-Err_Y_LAST)*Kd_y);//9300
//
//		if(PWM_Y>730)PWM_Y=730;
//		if(PWM_Y<630)PWM_Y=630;
//
//		if(PWM_X>800)PWM_X=800;//9410
//		if(PWM_X<700)PWM_X=700;//9270
//	//	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
//	   	Err_X_LAST=Err_X;
//	  	Err_Y_LAST=Err_Y;
//		//printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
//			TIM_SetCompare1(TIM2,PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
//			TIM_SetCompare2(TIM2,PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
//		//	LED1=!LED1;
//}
//

void Mode_6(void)
{
    u8 num = 20, i;

    static  u8 key_flag = 1;

    if ( key_flag  )
    {
        OLED_Clear();
        OLED_ShowChar(8, 0, 'A');
        OLED_ShowChar(8, 2, 'B');
        OLED_ShowChar(8, 4, 'C');
        OLED_ShowChar(8, 6, 'D');
        for(i = 0; i < 4; i++)
        {
            while(num == 20)
            {
                num = Read_KeyValue();
            }
            OLED_ShowNum(56, i * 2, num, 1, 16);
            table_setx[i] = table_x[num - 1];
            table_sety[i] = table_y[num - 1];
            num = 20;

        }
        key_flag = 0;
        OLED_Clear();
    }


    TIM_Cmd(TIM5, ENABLE);
    if (flag_2s == 1  )
    {
        flag_2s = 0;
        asd++;
        if (asd > 20)
        {

            TIM_Cmd(TIM5, DISABLE);
            TIM5->CNT = 0;
        }
    }

    Aim_X = table_setx[0];
    Aim_Y = table_sety[0];

    if (asd > 0)
    {
        Aim_X = table_setx[1];
        Aim_Y = table_sety[1];
    }
    if(asd > 1)
    {
        Aim_X = table_setx[2];
        Aim_Y = table_sety[2];
    }
    if(asd > 2)
    {
        Aim_X = table_setx[3];
        Aim_Y = table_sety[3];
    }

    Kp_x = -2; //-      -2
    Ki_x = -0.01;
    Kd_x = -16; //2.7

    Kp_y = 2; //+
    Ki_y = 0.01;
    Kd_y = 16; //+



    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}






void Mode_7(void)
{


    TIM_Cmd(TIM5, ENABLE);
    if (flag_1s == 1  )
    {
        flag_1s = 0;
        dsa++;
        if (dsa > 200)
        {

            TIM_Cmd(TIM5, DISABLE);
            TIM5->CNT = 0;
        }
    }

    if (dsa < 40)
    {
        if ( dsa % 8 == 0 ) {

            Aim_X = 206;
            Aim_Y = 130;

        }
        if ( dsa % 8 == 4) {
            Aim_X = 123;
            Aim_Y = 130;

        }
        if ( dsa % 8 == 5) {
            Aim_X = 125;
            Aim_Y = 177;

        }
        if ( dsa % 8 == 6) {
            Aim_X = 168;
            Aim_Y = 174;

        }
        if ( dsa % 8 == 7) {
            Aim_X = 205;
            Aim_Y = 170;

        }
        if ( dsa % 8 == 2) {
            Aim_X = 172;
            Aim_Y = 85;

        }
        if ( dsa % 8 == 3) {
            Aim_X = 122;
            Aim_Y = 82;

        }
        if ( dsa % 8 == 1) {
            Aim_X = 208;
            Aim_Y = 88;

        }


    }
    else
    {
        Aim_X = 245;
        Aim_Y = 60;
    }



    Kp_x = -2; //-      -2
    Ki_x = -0.01;
    Kd_x = -15; //2.7

    Kp_y = 2; //+
    Ki_y = 0.01;
    Kd_y = 15; //+


    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}



void Mode_5(void)
{


    TIM_Cmd(TIM5, ENABLE);
    if (flag_2s == 1  )
    {
        flag_2s = 0;
        asd++;
        if (asd > 8)
        {

            TIM_Cmd(TIM5, DISABLE);
            TIM5->CNT = 0;
        }
    }

    Aim_X = 72;
    Aim_Y = 132;

    if (asd > 0)
    {
        Aim_X = 170;
        Aim_Y = 60;
    }
    if(asd > 1)
    {
        Aim_X = 250;
        Aim_Y = 67;

    }

    Kp_x = -1.5; //-      -2
    Ki_x = -0.01;
    Kd_x = -18; //2.7

    Kp_y = 1.5; //+
    Ki_y = 0.01;
    Kd_y = 18; //+


//		Aim_X=79;
//		Aim_Y=140;

//		Aim_X=170;
//		Aim_Y=80;

//		Aim_X=244;
//		Aim_Y=100;

    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}




void Mode_4(void)
{

    TIM_Cmd(TIM5, ENABLE);
    Kp_x = -2; //-      -2
    Ki_x = -0.01;
    Kd_x = -18; //2.7

    Kp_y = 2; //+
    Ki_y = 0.01;
    Kd_y = 18; //+


    Aim_X = 168;
    Aim_Y = 173;


    if (flag_2s == 1  )
    {
        flag_2s = 0;
        asd++;
        if (asd > 8)
        {

            TIM_Cmd(TIM5, DISABLE);
            TIM5->CNT = 0;
        }
    }

    if (asd > 0)
    {
        Aim_X = 207;
        Aim_Y = 127;
    }
    if(asd > 1)
    {
        Aim_X = 249;
        Aim_Y = 62;

    }

    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}

void Mode_3(void)
{
    TIM_Cmd(TIM5, ENABLE);
    Kp_x = -2; //-      -2
    Ki_x = -0.01;
    Kd_x = -12; //2.7

    Kp_y = 2; //+
    Ki_y = 0.01;
    Kd_y = 12; //+


    Aim_X = 162;
    Aim_Y = 207;

//	if (flag_2s==1)
//{
//		TIM_Cmd(TIM5, DISABLE);
//	  TIM5->CNT=0;
//		Aim_X=171;
//		Aim_Y=147;
//}

    ttt++;
    if (ttt > 100  )
    {
        Aim_X = 168;
        Aim_Y = 134;
    }

    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}


int yici(u16 x1, u16 y1, u16 x2, u16 y2, u16 chanru)
{
    return (y1 + y2) / (x1 + x2) * chanru;
}


void Mode_2(void)
{

    Kp_x = -2; //-      -2
    Ki_x = -0.01;
    Kd_x = -18; //2.7

    Kp_y = 2; //+
    Ki_y = 0.01;
    Kd_y = 18; //+


    Aim_X = 168;
    Aim_Y = 131;

    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}

void Mode_1(void)
{
    Kp_x = -1; //-      -2
    Ki_x = -0;
    Kd_x = -8; //2.7

    Kp_y = 1; //+
    Ki_y = 0;
    Kd_y = 8; //+


    Aim_X = 79;
    Aim_Y = 128;

    Err_X = X - Aim_X;
    Err_Y = Y - Aim_Y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;
    //printf("_X=%f  _y= %f \r\n",Err_X,Err_Y);

    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 680 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 730)PWM_Y = 730;
    if(PWM_Y < 630)PWM_Y = 630;

    if(PWM_X > 800)PWM_X = 800; //9410
    if(PWM_X < 700)PWM_X = 700; //9270
    //	printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}

void Mode_0(void)
{

    PWM_X = 750;
    PWM_Y = 680;

    //printf("PWM_X=%f  PWM_y= %f \r\n",Err_X_LAST,Err_Y_LAST);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    //	LED1=!LED1;
}

void Mode_8(void)
{
    u32 MoveTimeCnt = 0;
    float set_x = 0.0;
    float set_y = 0.0;
    float A = 0.0;
    float phase = 0.0;
    float Normalization = 0.0;
    float Omega = 0.0;


    Kp_x = -2;
    Ki_x = -0.01;
    Kd_x = -13;

    Kp_y = 2;
    Ki_y = 0.01;
    Kd_y = 13;


    MoveTimeCnt += 5;
    Normalization = (float)MoveTimeCnt / 1410;
    Omega = 2.0 * 3.14159 * Normalization;
    A = atan((R / 88.0f)) * 57.2958f;


    phase = 3.141592 / 2.0;		 //��ʱ����ת��λ��90��


    set_x = A * sin(Omega);			 //�����X����ǰ�ڽ�
    set_y = A * sin(Omega + phase); 	 //�����Y����ǰ�ڽ�

    Err_X = X - set_x;
    Err_Y = Y - set_y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;


    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 750 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 1250)PWM_Y = 1250;
    if(PWM_Y < 250)PWM_Y = 250;

    if(PWM_X > 1250)PWM_X = 1250; //9410
    if(PWM_X < 250)PWM_X = 250; //9270

    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //	printf("PWM_X=%d  PWM_y= %d \r\n",PWM_X,PWM_Y);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
}
void  get(  Camera_DataTypeDef* now )
{
    X = now->ucPosX;
    Y = now->ucPosY;
}

void Mode_9(void)
{
    u32 MoveTimeCnt = 0;
    float set_x = 0.0;
    float set_y = 0.0;
    float A = 0.0;
    float phase = 0.0;
    float Normalization = 0.0;
    float Omega = 0.0;


    Kp_x = -2;
    Ki_x = -0.01;
    Kd_x = -13;

    Kp_y = 2;
    Ki_y = 0.01;
    Kd_y = 13;


    MoveTimeCnt += 5;
    Normalization = (float)MoveTimeCnt / 1410;
    Omega = 2.0 * 3.14159 * Normalization;
    A = atan((R / 88.0f)) * 57.2958f;


    phase = 3.141592 / 4.0;		 //��ʱ����ת��λ��45��


    set_x = A * sin(Omega);			 //�����X����ǰ�ڽ�
    set_y = 2 * A * sin(Omega + phase); 	 //�����Y����ǰ�ڽ�

    Err_X = X - set_x;
    Err_Y = Y - set_y;

    SumError_X += Err_X;
    SumError_Y += Err_Y;


    if(SumError_X > 1000.0)					//�����޷�
        SumError_X = 1000.0;
    else if(SumError_X < -1000.0)
        SumError_X = -1000.0;

    if(SumError_Y > 1000.0)					//�����޷�
        SumError_Y = 1000.0;
    else if(SumError_Y < -1000.0)
        SumError_Y = -1000.0;


    PWM_X = 750 + (Err_X * Kp_x + SumError_X * Ki_x + (Err_X - Err_X_LAST) * Kd_x);
    PWM_Y = 750 + (Err_Y * Kp_y + SumError_Y * Ki_y + (Err_Y - Err_Y_LAST) * Kd_y); //9300

    if(PWM_Y > 1250)PWM_Y = 1250;
    if(PWM_Y < 250)PWM_Y = 250;

    if(PWM_X > 1250)PWM_X = 1250; //9410
    if(PWM_X < 250)PWM_X = 250; //9270

    Err_X_LAST = Err_X;
    Err_Y_LAST = Err_Y;
    //	printf("PWM_X=%d  PWM_y= %d \r\n",PWM_X,PWM_Y);
    TIM_SetCompare1(TIM2, PWM_X);	//�޸ıȽ�ֵ���޸�ռ�ձ�
    TIM_SetCompare2(TIM2, PWM_Y);	//�޸ıȽ�ֵ���޸�ռ�ձ�
}


int main(void)
{

    Camera_DataTypeDef PosData;
    delay_init();	    	 //��ʱ������ʼ��
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
    uart_init(115200);	 	//���ڳ�ʼ��Ϊ 115200
    uart2_init(115200);
    usmart_dev.init(72);		//��ʼ��USMART
    KeyGPIO_Init();				//��ʼ������
    OLED_Init();			//��ʼ��OLED
    OLED_Clear();
    PWM_Init();
    //TIM4_Int_Init(50000,71);
    // TIM6_Int_Init(50000-1,71);
    // TIM3_Int_Init(50000,71);//10Khz�ļ���Ƶ�ʣ�������5000Ϊ500ms
    TIM5_Int_Init(9999, 71); //10Khz�ļ���Ƶ�ʣ�������5000Ϊ500ms
    // TIM3_PWM_Init(9999,143);

    EXTI_PB0_Config();
    EXTI_PE4_Config();



    while(1)
    {

////  key=Read_KeyValue();
////  if(key!=20) {key_question=key;OLED_Clear();}
        if(Camera_GetFalg())
        {
            Camera_TranslateData(&PosData);
            Camera_ResetFlag();
            get(  &PosData );
            switch(mode)
            {
            case 0:
                Mode_0();
                OLED_ShowString(30, 0, "test");
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 1:
                Mode_1();
                OLED_ShowString(20, 0, "question");
                OLED_ShowNum(88, 0, key_question, 1, 16);
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 2:
                Mode_2();
                OLED_ShowString(20, 0, "question");
                OLED_ShowNum(88, 0, key_question, 1, 16);
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 3:
                Mode_3();
                OLED_ShowString(20, 0, "question");
                OLED_ShowNum(88, 0, key_question, 1, 16);
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 4:
                Mode_4();
                OLED_ShowString(20, 0, "question");
                OLED_ShowNum(88, 0, key_question, 1, 16);
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 5:
                Mode_5();
                OLED_ShowString(20, 0, "question");
                OLED_ShowNum(88, 0, key_question, 1, 16);
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 6://Mode_6();
//OLED_ShowString(20,0,"question");OLED_ShowNum(88,0,key_question,1,16);
//OLED_ShowChar(12,4,'X');
//OLED_ShowNum(30,4,X,3,16);
//OLED_ShowChar(12,6,'Y');
//OLED_ShowNum(30,6,Y,3,16);break;
            case 7:
                Mode_7();
                OLED_ShowString(20, 0, "question");
                OLED_ShowNum(88, 0, key_question, 1, 16);
                OLED_ShowChar(12, 4, 'X');
                OLED_ShowNum(30, 4, X, 3, 16);
                OLED_ShowChar(12, 6, 'Y');
                OLED_ShowNum(30, 6, Y, 3, 16);
                break;
            case 8://Mode_8();
//OLED_ShowString(20,0,"question");OLED_ShowNum(88,0,key_question,1,16);
//OLED_ShowChar(12,4,'X');
//OLED_ShowNum(30,4,X,3,16);
//OLED_ShowChar(12,6,'Y');
//OLED_ShowNum(30,6,Y,3,16);break;
            case 9://Mode_9();
//OLED_ShowString(20,0,"question");OLED_ShowNum(88,0,key_question,1,16);
//OLED_ShowChar(12,4,'X');
//OLED_ShowNum(30,4,X,3,16);
//OLED_ShowChar(12,6,'Y');
//OLED_ShowNum(30,6,Y,3,16);break;
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
                break;//key=20;OLED_ShowString(0,0,"please");OLED_ShowString(20,2,"choose");OLED_ShowString(40,4,"question");break;
defeat :
                break;
            }
        }
    }
}

//��ʱ��3�жϷ������
void TIM5_IRQHandler(void)   //TIM3�ж�
{


    if (TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET)  //���TIM3�����жϷ������
    {
        TIM_ClearITPendingBit(TIM5, TIM_IT_Update  );  //���TIMx�����жϱ�־
        k++;
        d++;
        if (d == 200)
        {
            d = 0;
            flag_1s = 1;
        }

        if (k == 400)
        {
            k = 0;
            flag_2s = 1;
        }
    }
}


void TIM6_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET) //���ָ����TIM�жϷ������:TIM �ж�Դ
    {
        m++;
        if(m == 20) {
            flag6_2s = 1;
            m = 0	;
        }
    }
    TIM_ClearITPendingBit(TIM6, TIM_IT_Update  );  //���TIMx���жϴ�����λ:TIM �ж�Դ
}

