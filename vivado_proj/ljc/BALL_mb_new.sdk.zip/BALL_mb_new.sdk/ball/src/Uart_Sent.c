
#include "Uart_Sent.h"

#define BUFFER_SIZE 8

u8 x_high,x_low;
u8 y_high,y_low;
u8 SendBuffer[BUFFER_SIZE];

u8 HEAD1 = 0x55;
u8 HEAD2 = 0xaa;
u8 HEAD3 = 0x01;
u8 FNSH = 0x24;

XUartLite UartLite_1;

int uart_sent(u16 coordx,u16 coordy)
{
	x_low  = coordx;
	x_high = coordx >> 8;
	y_low  = coordy;
	y_high = coordy >> 8;

	SendBuffer[0] = HEAD1;
	SendBuffer[1] = HEAD2;
	SendBuffer[2] = HEAD3;
	SendBuffer[3] = x_high;
	SendBuffer[4] = x_low;
	SendBuffer[5] = y_high;
	SendBuffer[6] = y_low;
	SendBuffer[7] = FNSH;

	XUartLite_Send(&UartLite_1, SendBuffer, BUFFER_SIZE);

	return 1;
}

