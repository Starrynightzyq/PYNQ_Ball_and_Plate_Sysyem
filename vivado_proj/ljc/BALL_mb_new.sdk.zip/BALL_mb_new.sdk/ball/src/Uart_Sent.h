/*
 * Uart_Sent.h
 *
 *  Created on: 2019��1��2��
 *      Author: LJC
 */
#include "xuartlite.h"

int uart_sent(u16 coordx,u16 coordy);
