/*
 * task.h
 *
 *  Created on: 2018��9��5��
 *      Author: admin
 */

#ifndef SRC_TASK_H_
#define SRC_TASK_H_

#include "pid.h"
#include "servo.h"

void task1(void);
void task1_init(void);

void task_test_servo(void);

#endif /* SRC_TASK_H_ */
